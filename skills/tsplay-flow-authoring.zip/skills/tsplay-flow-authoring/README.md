# TSPlay Flow Authoring

面向 Codex 的可分享 skill，用来帮助开发者编写、修复、review TSPlay Flow。

这份 skill 重点支持：

- 用自然语言把需求收敛成 TSPlay `.flow.yaml`
- 修已有 Flow 的 selector、等待、断言、变量链路、会话复用
- 读取本地 JSON 配置或前一步 artifact，并继续驱动后续 Flow
- 接管真实 Chrome/Chromium/Edge，或用 `cdp_launch` 自动启动独立 profile
- 编写邮件通知、失败告警、附件邮件等 `send_email` Flow
- 用中文或英文提问
- 按场景快速找到起手示例
- 按 MCP 的 `finalize -> run -> repair` 思路组织 Flow 工作流

## 适合什么场景

- 写新的 TSPlay Flow
- 修一条已经存在的 Flow
- 写邮件通知或附件发送 Flow
- 给团队做教程风格 Flow
- review Flow 的可维护性
- 把中文业务需求整理成稳定的 Flow
- 把“复用真实浏览器 / 免登录 / 反机器人检测较强页面”的需求整理成 CDP Flow 或 MCP 调用

## 安装方式

### 方式 1：运行安装脚本

如果你是把 skill 目录先解压到任意临时目录，推荐直接运行安装脚本：

macOS / Linux:

```bash
cd tsplay-flow-authoring
sh ./install.sh
```

Windows PowerShell:

```powershell
Set-Location .\tsplay-flow-authoring
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

Windows CMD:

```bat
cd tsplay-flow-authoring
install.cmd
```

如果你使用了自定义 `CODEX_HOME`：

```bash
sh ./install.sh --codex-home /path/to/codex-home
```

如果 `tsplay` 已经在 PATH 里，也可以安装后顺手释放内置参考资料：

```bash
sh ./install.sh --extract-assets ./tsplay-assets
```

### 方式 2：复制到 Codex skills 目录

把整个目录复制到：

```text
~/.codex/skills/tsplay-flow-authoring
```

如果你使用了自定义 `CODEX_HOME`，则复制到：

```text
$CODEX_HOME/skills/tsplay-flow-authoring
```

### 方式 3：直接分发压缩包后解压

把压缩包解压到：

```text
~/.codex/skills/
```

解压后目录结构应当像这样：

```text
~/.codex/skills/tsplay-flow-authoring/
  SKILL.md
  install.sh
  install.cmd
  install.ps1
  agents/openai.yaml
  references/
```

GitHub Release 会同时生成面向 Codex / OpenClaw 的命名包：

- `tsplay-flow-authoring-codex_<version>.zip`
- `tsplay-flow-authoring-openclaw_<version>.zip`

这两个包内容相同，都是标准 `SKILL.md` skill 目录；区别只是方便不同 Agent 分发渠道识别。

## 运行前假设

- 优先使用当前 PATH 里的 `tsplay`
- 如果在 TSPlay 仓库内，也可以用 `./tsplay` 或 `go run .`
- 不要求 skill 绑定某个固定绝对路径的可执行文件

## 如何触发这份 skill

典型中文触发词：

- 帮我写一条 TSPlay Flow
- 帮我修这条 Flow
- 把这个需求转成 Flow
- 帮我排查这条 Flow 为什么跑不通
- 帮我按 MCP 思路收敛成 Flow
- 帮我接管本机 Chrome
- 帮我用 cdp_launch 跑真实浏览器
- 帮我写一条发邮件的 Flow
- 帮我做一个邮件通知 Flow

典型英文触发词：

- write flow
- fix flow
- review flow
- generate flow
- repair selector
- attach Chrome over CDP
- use cdp_launch
- convert a requirement into Flow
- send email flow
- email notification flow

## 建议阅读顺序

### 中文用户

1. `references/zh-cn.md`
2. `references/zh-cn-business-templates.md`
3. `references/zh-cn-selectors.md`
4. `references/zh-cn-troubleshooting.md`
5. `references/zh-cn-review-checklist.md`

### 通用入口

1. `references/flow-authoring.md`
2. `references/actions.md`
3. `references/examples.md`
4. `references/example-index.md`

## 文件说明

- `SKILL.md`: skill 触发条件和主工作流
- `install.sh`: macOS / Linux 安装脚本
- `install.cmd`: Windows CMD 入口脚本
- `install.ps1`: Windows PowerShell 安装脚本
- `agents/openai.yaml`: Codex UI 元数据
- `references/flow-authoring.md`: Flow 编写主指南
- `references/actions.md`: 高频 action 速查
- `references/examples.md`: 提示词模板和最小示例
- `references/example-index.md`: 按场景分类的 repo 起手示例
- `references/zh-cn.md`: 中文总入口
- `references/zh-cn-business-templates.md`: 中文业务场景模板
- `references/zh-cn-troubleshooting.md`: 中文报错与修复对策
- `references/zh-cn-selectors.md`: 中文 selector 策略速查
- `references/zh-cn-review-checklist.md`: 中文 Flow review 清单
- `references/repo-map.md`: 在 TSPlay 仓库里工作时的路径和命令索引

## 邮件能力说明

- TSPlay 的动作名是 `send_email`
- 适合发送成功通知、失败告警、导出结果邮件、附件报告
- 需要发邮件时，受限上下文下要考虑 `allow_email`
- 如果邮件带附件，还要同时考虑文件访问权限
- SMTP 配置既可以走 `connection` 对应的环境变量，也可以直接写 `with.smtp`

## CDP / 真实浏览器说明

- `browser.cdp_launch: true`：让 TSPlay 自动查找 macOS / Windows / Linux 常见 Chrome、Chromium、Edge，启动独立 profile，再通过 CDP 接管
- `browser.cdp_port: 9222`：接管已经用 `--remote-debugging-port=9222` 启动的外部浏览器
- `browser.cdp_endpoint`：可传 `ws://127.0.0.1:9222/devtools/browser/...`、`http://127.0.0.1:9222`，也可直接粘贴 `127.0.0.1:9222/json/version`、`127.0.0.1:9222/json/list`、`127.0.0.1:9222/json/new`、`127.0.0.1:9222/json/protocol` 或 `/devtools/browser/...`
- 外部 CDP 接管结束时，TSPlay 只断开连接，不关闭真实浏览器
- `cdp_launch` 启动的浏览器由 TSPlay 管理，运行结束会回收
- MCP 下使用 Flow `browser.cdp_*` 或工具参数 `browser_cdp_*` 时，必须传 `allow_browser_state=true`
- 如果还要写 JSON / CSV / 截图，需要 `allow_file_access=true`；如果用 `execute_script` / `evaluate`，需要 `allow_javascript=true`
- CDP 模式不能和 `browser.use_session`、`storage_state/load_storage_state`、persistent `profile/session`、`user_agent` 或浏览器页面录制混用

## 最小使用模板

```text
帮我写一条 TSPlay Flow。
- 页面: <URL 或本地页面>
- 目标: <要完成的业务动作>
- 输入: <关键词 / 文件 / 条件，没有就写无>
- 输出: <save_as / JSON / CSV / Excel / artifact 路径>
- 授权: <readonly / browser_write / full_automation / allow_*>
```

## 一个读 JSON 的模板

```text
帮我写一条 TSPlay Flow 读取本地 JSON。
- 文件: <json 文件路径>
- 目标: <读取后要提取哪些字段，或后续要做什么>
- 输出: <save_as / JSON / CSV / 下游变量>
- 授权: <如果在受限上下文里，说明文件权限>
```

## 一个中文修 Flow 模板

```text
帮我修这条 TSPlay Flow。
- 文件: <flow 文件路径>
- 问题: <超时 / 找不到 selector / assert_text 失败 / 输出为空>
- 预期: <修完后应该得到什么结果>
- 限制: <不要改业务意图 / 不要转 Lua / 保持 artifact 路径>
```

## 分享建议

- 对团队内部分发：直接发整个 `tsplay-flow-authoring` 目录或压缩包
- 对已经在用 Codex 的同事：让对方解压到 `~/.codex/skills/`
- 对中文团队：优先让大家从 `references/zh-cn.md` 开始

## 版本说明

这是一份偏“Flow authoring / repair / review”的 TSPlay skill，不是通用浏览器自动化百科。它的目标是帮助开发者更快写出可 review、可维护的 TSPlay Flow。
